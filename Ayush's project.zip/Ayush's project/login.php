








<!DOCTYPE html>
<html lang="en">

<head>
    <title>ayush's web</title>
    <link rel="stylesheet" href="signup.css">
</head>

<body>

    <div class="main">
        <div class="logo">
            <a href="logo">Web-Project</a>
        </div>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="signup.php">Signup</a></li>
            
        </ul>
    </nav>    
    </div>

<div class="container">
<form action="login_process.php" method="post">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>

        <input type="submit" value="Login">
    </form>
</div>
   


</body>

</html>
<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

require_once('db.php');
$username = $_SESSION['username'];
$query = "SELECT * FROM users WHERE username='$username'";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $email = $row['email'];
    $fullname = $row['fullname'];
} else {
    // Handle error, user not found scenario
    echo "User not found";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Profile</title>
    <link rel="stylesheet" href="update.css">
</head>
<body>
        <div class="main">
        <div class="logo">
            <a href="logo">Web-Project</a>
        </div>
        <nav>
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="login.php">Login</a></li>
            
        </ul>
    </nav>    
    </div>
    <h2>Update Profile</h2>
    <form action="update_profile_process.php" method="post">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" value="<?php echo $_SESSION['username']; ?>" readonly><br><br>

        <label for="new_password">New Password:</label><br>
        <input type="password" id="new_password" name="new_password"><br><br>

        <label for="new_email">New Email:</label><br>
        <input type="email" id="new_email" name="new_email" value="<?php echo $email; ?>"><br><br>

        <label for="new_fullname">New Full Name:</label><br>
        <input type="text" id="new_fullname" name="new_fullname" value="<?php echo $fullname; ?>"><br><br>

        <input type="submit" value="Update">
    </form>
</body>
</html>













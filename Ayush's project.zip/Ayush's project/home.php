<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>ayush's web</title>
    <link rel="stylesheet" href="home.css">
</head>
<body>
<div class="main">
        <div class="logo">
            <a href="logo">Web-Project</a>
        </div>
    <nav>
        <ul>
            <li><a href="profile.php">View Profile</a></li>
            <li><a href="logout.php">Logout</a></li>     
        </ul>
    </nav>    
    </div>
<body>
    <h2>Welcome, <?php echo $_SESSION['username']; ?> <br><br> Now, you can review your profile and also you can update your profile from "view profile"</h2>
</body>
</html>

<?php
$db_host = 'localhost'; // Database host
$db_user = 'root';  // Database username
$db_password = ''; // Database password
$db_name = 'database'; // Database name

// Establish database connection
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

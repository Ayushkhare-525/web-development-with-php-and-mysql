<!DOCTYPE html>
<html lang="en">

<head>
    <title>ayush's web</title>
    <link rel="stylesheet" href="about.css">
</head>

<body>

    <div class="main">
        <div class="logo">
            <a href="logo"> Web-Project</a>
        </div>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="portfolio.php">Portfolio </a></li>
            <li><a href="signup.php">Contact</a></li>
            
        </ul>
    </nav>    
    </div>


<div class="main-page">
    <p>
        My name is<b style="color:white"> Ayush Khare </b>     ,<br></p><p> I am pursuing B.tech from Kali Charan Nigam Institute Of Technology Banda.<br></p>
        <p> I am student of Computer Science & Engineering.<br></p>
        <p>Currently, I am doing a Web Development Course from Online Platform <b style="color:white">InternShala.</b> 
    </p>
</div>

</body>

</html>
<?php
session_start();
require_once('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_SESSION['username']);
    $new_password = mysqli_real_escape_string($conn, $_POST['new_password']);
    $new_email = mysqli_real_escape_string($conn, $_POST['new_email']);
    $new_fullname = mysqli_real_escape_string($conn, $_POST['new_fullname']); // Sanitize input
    
    // Initialize array to store update queries
    $update_queries = array();

    // Hash new password securely if provided
    if (!empty($new_password)) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $update_queries[] = "UPDATE users SET password='$hashed_password' WHERE username='$username'";
    }

    // Update email if provided
    if (!empty($new_email)) {
        $update_queries[] = "UPDATE users SET email='$new_email' WHERE username='$username'";
    }

    // Update fullname if provided
    if (!empty($new_fullname)) {
        $update_queries[] = "UPDATE users SET fullname='$new_fullname' WHERE username='$username'";
    }

    // Execute all update queries
    $success = true;
    foreach ($update_queries as $query) {
        if (!mysqli_query($conn, $query)) {
            $success = false;
            echo "Error updating profile: " . mysqli_error($conn) . "<br>";
        }
    }

    if ($success) {
        echo "Profile updated successfully";
    }
}

mysqli_close($conn);
?>

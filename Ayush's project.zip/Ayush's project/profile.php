<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

require_once('db.php');
$username = $_SESSION['username'];
$query = "SELECT * FROM users WHERE username='$username'";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $email = $row['email'];
    $fullname = $row['fullname'];
} else {
    // Handle error, user not found scenario
    echo "User not found";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>ayush's web</title>
    <link rel="stylesheet" href="profile.css">
</head>
<body>
<div class="main">
        <div class="logo">
            <a href="logo">Web-Project</a>
        </div>
    <nav>
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="update_profile.php">Update Profile</a></li>     
            <li><a href="logout.php">Logout</a></li>   
        </ul>
    </nav>    
    </div>
<body>
    <div class="profile-content">
    <h2>Profile</h2>
    <p>Username: <?php echo $_SESSION['username']; ?></p>
    <p>Email: <?php echo $email; ?></p>
    <p>Full Name: <?php echo $fullname; ?></p>
    </div>
</body>
</html>

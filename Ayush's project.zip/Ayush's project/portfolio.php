<!DOCTYPE html>
<html lang="en">

<head>
    <title>ayush's web</title>
    <link rel="stylesheet" href="portfolio.css">
</head>

<body>

    <div class="navBar">
        <div class="logo">
            <a href="logo">Web-Project</a>
        </div>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="signup.php">Contact</a></li>
            
        </ul>
    </nav>    
    </div>


    <section class="main">
        <div class="left">
          <div class="content">
            <span style="color: white;">Hi, I am</span> <span style="color: rgb(243, 211, 67);">AYUSH KHARE
            </span><br><span style="line-height: 45px; color: white;">and I am Passionate creative with a flair for design and a knack for problem-solving.
               Dedicated to crafting engaging user experiences through innovative solutions. </span>
          </div>
        </div>
        <div class="right">
          <img width="420px" height="340px" src="business-man-2356422_1280 (1) (1).png" alt="">
          <div class="div-shape">
            
          </div>
        </div>
      </section>
    
    
    
      <div class="hr1"></div>
      <div class="skill-header">
        <h1>Skills</h1>
      </div>
      <div class="box">
        <div class="horizontal">
          <img width="60px" height="60px" id="icon-1" class="icon" src="html-5.png" alt="">
          <div class="horizontal-title">
           
            <h1>HTML</h1>
          </div>
          <div class="hortzontal-desc">
    
          </div>
        </div>
        <div class="horizontal">
          <img width="60px" height="60px" id="icon-1" class="icon" src="css.png" alt="">
          <div class="horizontal-title">
            <h1>CSS</h1>
          </div>
        </div>
        <div class="horizontal">
          <img width="60px" height="60px" id="icon-1" class="icon" src="js.png" alt="">
          <div class="horizontal-title">
            <h1>Javascript</h1>
          </div>
        </div>
        <div class="horizontal">
          <img width="60px" height="60px" id="icon-1" class="icon" src="bootstrap.png" alt="">
          <div class="horizontal-title">
            <h1>bootstrap</h1>
          </div>
        </div>
      </div>
    
    

</body>

</html>
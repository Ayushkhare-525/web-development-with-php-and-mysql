<!DOCTYPE html>
<html lang="en">

<head>
    <title>Ayush's web</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="container">
<div class="main">
        <div class="logo">
            <a href="logo">Web-Project</a>
        </div>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="portfolio.php">Portfolio</a></li>
            <li><a href="signup.php">Signup</a></li>
            
        </ul>
    </nav>    
    </div>


    <!--  Content  -->



    <div class="content">
        <h1>Web Development Project</h1>
        <p style="color:rgb(212, 134, 16);">"Developing a dynamic web application using PHP and MySQL for efficient data management and user interaction."</p>
        <div class="button">
            <button>
                <a href="signup.php">Join with us</a>
            </button>
        </div>
    </div>
</div>

    <div class="main-div">

        <div class=left-div>

        </div>
        <div class="right-div">
            <div class="description">
                <h2>Business Development Strategies</h2>
                <p>Market Research and Analysis
                    <br> Analyzing competitor strategies and market dynamics to gain a competitive advantage.
                </p>
                <p>Strategic Planning<br>
                Formulating actionable plans for business expansion, product development, or market penetration.</p>
                <p>Sales and Marketing Strategies <br>
                Implementing digital marketing campaigns, branding initiatives, and customer engagement programs.</p>

            </div>
        </div>
    </div>
    <div class="main-div1">
        <div class=left-div1>
            <h2>Making Websites With Codes</h2>
<p>Content Management Systems (CMS): PHP powers many popular CMS platforms like WordPress, Joomla, and Drupal, allowing users to create and manage digital content effectively. <br>

E-commerce Websites: PHP frameworks such as Magento and WooCommerce enable the development of robust e-commerce platforms with features like product catalogs, shopping carts, and payment gateways.<br>

Web Applications: PHP frameworks like Laravel, Symfony, and CodeIgniter facilitate the development of complex web applications with MVC (Model-View-Controller) architecture, routing, and RESTful APIs.<br>

Dynamic Websites: PHP is ideal for creating websites that require dynamic content generation based on user input, database queries, or real-time data processing.</p>
        </div>
        <div class="right-div1">
           
        </div>
    </div>
    
    <footer>
        <div>
            <p>Contact us: logontoayushkhare@gmail.com</p>
            <p>Follow us: <a href="https://instagram.com/example" target="_blank">Instagram</a>, <a href="https://facebook.com/example" target="_blank">Facebook</a></p>
        </div>
        <div>
            <p>&copy; <?php echo date("Y"); ?> Web Development Projects.</p>
        </div>
    </footer>
</body>

</html>

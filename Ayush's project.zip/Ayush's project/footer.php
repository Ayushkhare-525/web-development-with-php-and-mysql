<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Page Title</title>
    <link rel="stylesheet" href="footer.css"> <!-- Link to your CSS file -->
</head>
<body>
    <!-- Header, main content, etc. -->

    <footer>
        <div>
            <p>Contact us: contact@example.com</p>
            <p>Follow us: <a href="https://twitter.com/example" target="_blank">Twitter</a>, <a href="https://facebook.com/example" target="_blank">Facebook</a></p>
        </div>
        <div>
            <p>&copy; <?php echo date("Y"); ?> Your Company Name. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>







<!DOCTYPE html>
<html lang="en">

<head>
    <title>ayush's web</title>
    <link rel="stylesheet" href="signup.css">
</head>

<body>

    <div class="main">
        <div class="logo">
            <a href="logo">Web-Project</a>
        </div>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="login.php">Login</a></li>
            
        </ul>
    </nav>    
    </div>

<div class="container">
<form action="signup_process.php" method="post">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>

        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="fullname">Full Name:</label><br>
        <input type="text" id="fullname" name="fullname"><br><br>

        <input type="submit" value="Signup">
    </form>
</div>
   


</body>

</html>